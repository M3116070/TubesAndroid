package com.kuliah.ahmad.listbuku.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.kuliah.ahmad.listbuku.activities.BukuActivity;
/*import com.kuliah.ahmad.tubes.activities.BukuDetail;*/
import com.kuliah.ahmad.listbuku.R;
import com.kuliah.ahmad.listbuku.model.Buku;

import java.text.BreakIterator;
import java.util.List;

/**
 * Created by Aws on 11/03/2018.
 */

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder> {

    private Context mContext ;
    private List<Buku> mData ;
    RequestOptions option;


    public RecyclerViewAdapter(Context mContext, List<Buku> mData) {
        this.mContext = mContext;
        this.mData = mData;

        // Request option for Glide
        option = new RequestOptions().centerCrop().placeholder(R.drawable.loading_shape).error(R.drawable.loading_shape);

    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view ;
        LayoutInflater inflater = LayoutInflater.from(mContext);
        view = inflater.inflate(R.layout.buku_row_item,parent,false) ;
        final MyViewHolder viewHolder = new MyViewHolder(view) ;
        viewHolder.view_container.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(mContext, BukuActivity.class);
                i.putExtra("judul_buku",mData.get(viewHolder.getAdapterPosition()).getJudul());
                i.putExtra("keterangan_buku",mData.get(viewHolder.getAdapterPosition()).getKeterangan());
                i.putExtra("harga_buku",mData.get(viewHolder.getAdapterPosition()).getHarga());
                i.putExtra("penulis_buku",mData.get(viewHolder.getAdapterPosition()).getPenulis());
                i.putExtra("penerbit_buku",mData.get(viewHolder.getAdapterPosition()).getPenerbit());
                i.putExtra("halaman_buku",mData.get(viewHolder.getAdapterPosition()).getHalaman());
                i.putExtra("terbit_buku",mData.get(viewHolder.getAdapterPosition()).getTerbit());
                i.putExtra("isbn_buku",mData.get(viewHolder.getAdapterPosition()).getIsbn());
                i.putExtra("img_buku",mData.get(viewHolder.getAdapterPosition()).getImage_url());

                mContext.startActivity(i);

            }
        });


        return viewHolder;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {

        holder.tv_judul.setText(mData.get(position).getJudul());
        holder.tv_harga.setText(mData.get(position).getHarga());
        holder.tv_penerbit.setText(mData.get(position).getPenerbit());
        holder.tv_penulis.setText(mData.get(position).getPenulis());



        // Load Image from the internet and set it into Imageview using Glide

        Glide.with(mContext).load(mData.get(position).getImage_url()).apply(option).into(holder.img_thumbnail);



    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {


        TextView tv_judul ;
        TextView tv_harga ;
        TextView tv_penerbit ;
        TextView tv_penulis;
        ImageView img_thumbnail;
        LinearLayout view_container;





        public MyViewHolder(View itemView) {
            super(itemView);

            view_container = itemView.findViewById(R.id.container);
            tv_judul = itemView.findViewById(R.id.judul_buku);
            tv_penulis = itemView.findViewById(R.id.penulis);
            tv_harga = itemView.findViewById(R.id.harga);
            tv_penerbit = itemView.findViewById(R.id.penerbit);
            img_thumbnail = itemView.findViewById(R.id.thumbnail);

        }
    }

}