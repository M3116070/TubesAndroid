package com.kuliah.ahmad.listbuku.activities;

import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.kuliah.ahmad.listbuku.R;

public class BukuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buku);

        // hide the default actionbar
        getSupportActionBar().hide();

        // Recieve data

        String judul  = getIntent().getExtras().getString("judul_buku");
        String keterangan = getIntent().getExtras().getString("keterangan_buku");
        String harga = getIntent().getExtras().getString("harga_buku") ;
        String penulis = getIntent().getExtras().getString("penulis_buku");
        String penerbit = getIntent().getExtras().getString("penerbit_buku");
        String halaman = getIntent().getExtras().getString("halaman_buku") ;
        String terbit = getIntent().getExtras().getString("terbit_buku");
        String isbn = getIntent().getExtras().getString("isbn_buku");
        String image_url = getIntent().getExtras().getString("img_buku") ;

        // ini views

        CollapsingToolbarLayout collapsingToolbarLayout = findViewById(R.id.collapsingtoolbar_id);
        collapsingToolbarLayout.setTitleEnabled(true);

        TextView tv_judul = findViewById(R.id.aa_judul_buku);
        TextView tv_penerbit = findViewById(R.id.aa_penerbit);
        TextView tv_penulis = findViewById(R.id.aa_penulis) ;
        TextView tv_keterangan = findViewById(R.id.aa_keterangan);
        TextView tv_harga  = findViewById(R.id.aa_harga);
        TextView tv_halaman  = findViewById(R.id.aa_halaman);
        TextView tv_terbit  = findViewById(R.id.aa_terbit);
        TextView tv_isbn  = findViewById(R.id.aa_isbn);
        ImageView img = findViewById(R.id.aa_thumbnail);

        // setting values to each view

        tv_judul.setText(judul);
        tv_penulis.setText(penulis);
        tv_keterangan.setText(keterangan);
        tv_harga.setText(harga);
        tv_penerbit.setText(penerbit);
        tv_halaman.setText(halaman);
        tv_terbit.setText(terbit);
        tv_isbn.setText(isbn);

        collapsingToolbarLayout.setTitle(judul);


        RequestOptions requestOptions = new RequestOptions().centerCrop().placeholder(R.drawable.loading_shape).error(R.drawable.loading_shape);


        // set image using Glide
        Glide.with(this).load(image_url).apply(requestOptions).into(img);





    }
}