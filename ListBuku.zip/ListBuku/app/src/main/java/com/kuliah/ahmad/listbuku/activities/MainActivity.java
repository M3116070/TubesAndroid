package com.kuliah.ahmad.listbuku.activities;

import android.content.Intent;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.kuliah.ahmad.listbuku.R;
import com.kuliah.ahmad.listbuku.adapter.RecyclerViewAdapter;
import com.kuliah.ahmad.listbuku.model.Buku;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;


public class MainActivity extends AppCompatActivity {

    private final String JSON_URL = "https://raw.githubusercontent.com/M3116070/TubesAndroid/master/buku.json";
    private JsonArrayRequest request;
    private RequestQueue requestQueue;
    private List<Buku> listBuku;
    private RecyclerView recyclerView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listBuku = new ArrayList<>();
        recyclerView = findViewById(R.id.recyclerviewid);
        jsonrequest();


    }

    private void jsonrequest() {

        request = new JsonArrayRequest(JSON_URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {

                JSONObject jsonObject = null;

                for (int i = 0; i < response.length(); i++) {


                    try {
                        jsonObject = response.getJSONObject(i);
                        Buku buku = new Buku();
                        buku.setJudul(jsonObject.getString("judul"));
                        buku.setKeterangan(jsonObject.getString("keterangan"));
                        buku.setHarga(jsonObject.getString("harga"));
                        buku.setPenulis(jsonObject.getString("penulis"));
                        buku.setPenerbit(jsonObject.getString("penerbit"));
                        buku.setHalaman(jsonObject.getString("halaman"));
                        buku.setTerbit(jsonObject.getString("terbit"));
                        buku.setIsbn(jsonObject.getString("isbn"));
                        buku.setImage_url(jsonObject.getString("img"));
                        listBuku.add(buku);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                }

                setuprecyclerview(listBuku);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });


        requestQueue = Volley.newRequestQueue(MainActivity.this);
        requestQueue.add(request);


    }

    private void setuprecyclerview(List<Buku> listBuku) {
        RecyclerViewAdapter myadapter = new RecyclerViewAdapter(this, listBuku);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(myadapter);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.option_menu, menu);
        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_ganti_bahasa) {
            Intent intent = new Intent(Settings.ACTION_LOCALE_SETTINGS);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
}