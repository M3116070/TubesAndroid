package com.kuliah.ahmad.listbuku.model;

public class Buku {

    private String judul ;
    private String keterangan;
    private String harga ;
    private String penulis;
    private String image_url;
    private String penerbit;
    private String halaman;
    private String terbit;
    private String isbn;

    public Buku() {
    }

    public Buku(String judul, String keterangan, String harga, String penulis, String image_url, String penerbit, String halaman, String terbit, String isbn) {
        this.judul = judul;
        this.keterangan = keterangan;
        this.harga = harga;
        this.penulis = penulis;
        this.image_url = image_url;
        this.penerbit = penerbit;
        this.halaman = halaman;
        this.terbit = terbit;
        this.isbn = isbn;
    }


    public String getJudul() {
        return judul;
    }

    public String getKeterangan() {
        return keterangan;
    }

    public String getHarga() {
        return harga;
    }

    public String getPenulis() {
        return penulis;
    }

    public String getImage_url() {
        return image_url;
    }

    public String getPenerbit() {
        return penerbit;
    }

    public String getHalaman() {
        return halaman;
    }

    public String getTerbit() {
        return terbit;
    }

    public String getIsbn() {
        return isbn;
    }



    public void setJudul(String judul) {
        this.judul = judul;
    }

    public void setKeterangan(String keterangan) {
        this.keterangan = keterangan;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public void setPenulis(String penulis) {
        this.penulis = penulis;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }

    public void setPenerbit(String penerbit) {
        this.penerbit = penerbit;
    }

    public void setHalaman(String halaman) {
        this.halaman = halaman;
    }

    public void setTerbit(String terbit) {
        this.terbit = terbit;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

}
